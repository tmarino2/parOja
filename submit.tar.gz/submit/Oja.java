import java.util.stream.IntStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.*;
import java.util.*;
import java.lang.*;
import java.util.Random;
import org.apache.commons.math3.linear.SingularValueDecomposition;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.RealMatrix;

public class Oja implements Runnable {
    public static double[][] U; //U is actually transposed here
    public static ArrayList<double[]> data;
    public static Random rand = new Random();
    public static int d;
    public static int k;
    public static double decay_fact;
    public static int n;
    public static int num_threads;
    String alg;
    private int from;
    private int to;
    private int curr_point;
    private double true_obj;
    private double eta;
    private int thread_id;
    private int increment;
    public static CyclicBarrier newBarrier;
    
    public Oja(int num_threads, int thread_id, String alg, ArrayList<double[]> data, int d, int k, double eta, double decay_fact) {
        this.data = data;
        this.n = data.size();
        this.d = d;
        this.k = k;
        this.thread_id = thread_id;
        curr_point = thread_id;
        this.eta = eta;
        this.decay_fact = decay_fact;
        this.num_threads = num_threads;
        this.increment = 1;
        
        newBarrier = new CyclicBarrier(2);
        this.alg = alg;
        U = new double[k][d];
        for(int i=0; i<k; i++) {
            true_obj+= Math.pow(decay_fact, i);
        }
        if(alg.equals(new String("hogwild"))) {
	    //System.out.println(alg);
            from = 0;
            to = k-1;
            this.increment = num_threads;
        } else {
            //k better be at least the number of threads
            int chunk_size = k/num_threads;
            if(thread_id < num_threads-1){
                from = thread_id*chunk_size;
                to = from+chunk_size-1;
            } else {
                from = thread_id*chunk_size;
                to = k-1;
            }
        }
        for(int i=0; i<k; i++) {
            for(int j=0; j<d; j++) {
                U[i][j] = rand.nextGaussian();
            }
        }
        SingularValueDecomposition svd = new SingularValueDecomposition(new Array2DRowRealMatrix(U));
        U = svd.getVT().getData();
        System.out.println(this.compute_obj()+" "+0);
    }
    
    void computeGrad_chunk(double eta_t, double[] x_t) {
        int k_chunk = to-from+1;
        double[][] U_chunk = new double[k_chunk][d];
        double inner_prod=0;
        for(int i=0; i<k_chunk; i++) {
            for(int j=0; j<d; j++) {
                inner_prod = 0;
                for (int l=0; l<d; l++) {
                    inner_prod+=x_t[l]*U[i][l];
                }
                U[i+from][j] += eta_t*x_t[j]*inner_prod;
            }
        }
    }
    
/*    void updateGrad_chunk(double eta, double[][] new_chunk) {
        for(int i=from; i<=to; i++) {
            for(int j=0; j<d; j++) {
                U[i][j] += eta*new_chnunk[i][j];
            }
        }
    }*/
    
    
    public void run() {
        while(curr_point < n) {
            computeGrad_chunk(this.eta/Math.pow(((double)(curr_point+1)),0.8), data.get(curr_point));
            //curr_point+=num_threads;
            curr_point += increment;
	    //if(curr_point%1000 == 0 && thread_id==0) {
	    //System.out.println(this.compute_obj()+" "+curr_point);
		//SingularValueDecomposition svd = new SingularValueDecomposition(new Array2DRowRealMatrix(U));
		//U = svd.getVT().getData();
		//}
            /*if(!(alg.equals(new String("hogwild")))){
                try {
                    System.out.println("in here");
                    Oja.newBarrier.await();
                } catch(InterruptedException | BrokenBarrierException e) {
                    System.err.println(e);
		}
		}*/
        }
    }
    
    public double compute_obj() {
        SingularValueDecomposition svd = new SingularValueDecomposition(new Array2DRowRealMatrix(U));
        Array2DRowRealMatrix diag_matr = new Array2DRowRealMatrix(d,d);
        RealMatrix U_matr = svd.getVT();
        for(int i=0; i<d; i++) {
            diag_matr.setEntry(i, i, Math.pow(decay_fact,i));
        }
        return true_obj - U_matr.multiply(diag_matr).multiply(U_matr.transpose()).getTrace();
    }
    
    public static void main(String[] args) {
        int num_threads = Integer.parseInt(args[0]);
        int num_points = Integer.parseInt(args[1]);
        int d = Integer.parseInt(args[2]);
        int k = Integer.parseInt(args[3]);
	double eta = Double.parseDouble(args[4]);
        double decay_fact = Double.parseDouble(args[5]);
        double err = 0;
        Random rand = new Random();
        String method = args[6];
        ArrayList<double[]> data = new ArrayList<double[]>();
        HashMap<Thread, Oja> ths = new HashMap<Thread, Oja>();
        double[] x_t = new double[d];
        for(int i=0; i<num_points; i++) {
            for(int j = 0; j<d; j++) {
                x_t[j] = Math.pow(decay_fact, j)*rand.nextGaussian();
            }
            data.add(x_t);
        }
        //ExecutorService executor = Executors.newFixedThreadPool(num_threads);
        long start_time = System.currentTimeMillis();
        for(int i=0; i<num_threads; i++) {
            Oja th_i = new Oja (num_threads, i, method, data, d, k, eta, decay_fact);
            Thread thr_i = new Thread(th_i);
            ths.put(thr_i, th_i);
            thr_i.start();
        }
        for(Map.Entry<Thread, Oja> th : ths.entrySet()) {
            try {
                th.getKey().join();
            } catch(InterruptedException e) {
                System.err.println(e);
            } finally {
               err = th.getValue().compute_obj();
            }
        }
        long end_time = System.currentTimeMillis();
        System.out.println("Elapsed time: "+Long.toString(end_time-start_time)+"ms");
        System.out.println("Error: "+ err);
    }
}
