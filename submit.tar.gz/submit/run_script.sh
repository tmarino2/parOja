#!/bin/bash
for k in {1,5,10}
do
for thr in {1,2,4}
do
for run in {1..10}
do
	java -cp .:./commons-math3-3.6.1.jar Oja $thr 100000 100 $k 0.4 0.8 nothogwild >> "${thr}_${k}_04_nothogwild.txt"
done
done
done
